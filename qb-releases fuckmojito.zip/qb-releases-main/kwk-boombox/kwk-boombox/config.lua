Config                            = {}

Config["translations"] = {
  tooClose = "~r~Too close to another speaker!",
  pickUp = "Press [E] to use [G] to pick up",
}

Config.Enable3DText = true
Config.UsingESX = false
Config.EnableCommand = true -- if false u can use TriggerEvent("kepo_speaker:place")