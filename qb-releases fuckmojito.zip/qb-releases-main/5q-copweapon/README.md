# esx_copweapon
Modification du tazer et des lacrimos
Tazer : Prolongation et modification de l'effet
Lacrimos : suppression de l'effet letal ajout d'effet visuel protection via masque a gaz
PS: il faut creer un item mask en bdd
