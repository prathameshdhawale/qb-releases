fx_version 'bodacious'
games { 'gta5' }

author 'Erratic'
description 'erratic_coke'
version '1.0.0'

client_scripts {
	'config.lua',
    'client/erratic_coke_cl.lua'
}

server_scripts {
	'config.lua',
    'server/erratic_coke_sv.lua'
}




