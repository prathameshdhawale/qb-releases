Config = {}

Config.Payment = math.random(330, 2000) -- How much you get paid when RN Jesus doesnt give you oxy, divided by 2 for when it does.
