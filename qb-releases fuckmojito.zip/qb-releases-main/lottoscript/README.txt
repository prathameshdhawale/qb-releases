This script is convert by Captainrum89

First of all DONT rename the folder (lotto).
Yust upload the lotto into your recources.
Add start lotto into your server.cfg

ADD THIS INTO YOUR shared.lua (in your qbcore folder)

["lotto"] 		 		     = {["name"] = "lotto",           		    ["label"] = "Lotto ticket",	 		    ["weight"] = 10, 		["type"] = "item", 		["image"] = "lotto.png", 			["unique"] = false, 	["useable"] = true, 	["shouldClose"] = true,    ["combinable"] = nil,   ["description"] = "Lucky Ticket"},


Upload the lotto.jpg  into your inventory/html/images folder


Have some FUN !!!