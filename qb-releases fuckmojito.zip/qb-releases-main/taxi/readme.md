for qbus
qbus-phone_new

Add them in 'qbus-phone_new files'.