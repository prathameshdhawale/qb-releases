# Discord
https://discord.gg/AYf7nWF

# Preview
https://streamable.com/haam1s

# Description
This mod adds the following:

- Allows players to request a train when near a train station.
- Allows players to request a metro when near a metro platform.
- Get on/off the train/metro at any point you want.
- The train/metro will stop at each train/metro stop (depending on which you are in) allowing you time to get off or stay on for a later platform/station.
- Easy to use.
- Very responsive and great performance levels.
- Easily configurable.

# How to use
- Go to the location where you want to request the train/metro.
- Use the chat command, "train" to request the train/metro
- This is also compatible with my "No Pixel Radial Interaction Menu.
- Once the train arrives, you have 30 seconds to board thr train/metro before it leaves.
- Press the key, "E" to get on/off the train.

# Installation
Add to folder '[esx]'
Write 'start reload-trains' in your server.cfg


#LICENSE
This mod was made by Reload with the intention to distribute.
He and he alone reserves the right to sell this script. Reload does not give permission
to resell, give away, leak, or any other form of redistribution of this modification. Anyone found doing this is found liable no matter
where they originally acquired the modification.
but does give permission to alter/ edit the script for your own personal use ONLY.

























































































































































-- Ryder