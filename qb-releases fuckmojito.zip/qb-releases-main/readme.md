Fuck World Of Scripts. Leaking our stuff LOL
