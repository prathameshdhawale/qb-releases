Script Name : OG-Gangs

Script Description : 
Consists Of 4 gangs (Ballas,Vagos,Marabunta,Thefamily)

Features:
- Fuck You Extra Leaks

Instructions: 
- Just add the jobs in qb-core/shared.lua
- You Will also Need The Interiors of all Gangs.They Are already available on World Of Forums.

Script Author : 
- @SBRULEZ#6969