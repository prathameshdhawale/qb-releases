resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

client_script "ms-client.lua"
server_script "ms-server.lua"